package com.lhz;

//实现输出指定信息

public class Exercise {

    public static void main(String[] args) {
        Exercise1();
        Exercise2();
    }

    private static void Exercise1() {
        System.out.println("---------练习1-----------");
        System.out.println("这是我的第一个Java程序");
    }

    private static void Exercise2() {
        System.out.println("---------练习2-----------");
        System.out.println("-------------");
        System.out.println(":  我要学会  :");
        System.out.println(":  Java语言  :");
        System.out.println("-------------");
    }


}
