package com.lhz.test;

public abstract class Exercise {
    abstract void doSomething();
}
