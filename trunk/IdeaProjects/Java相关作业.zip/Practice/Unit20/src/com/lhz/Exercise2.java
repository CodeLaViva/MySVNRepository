package com.lhz;

/**
 * 编写程序，实现向数据表tb_stu中添加数据的功能，要求
 * 姓名为“李某”
 * 性别是“女”
 * 出生日期是“1999-10-20”
 */
public class Exercise2 {
    public static void main(String[] args) {
        Jdbc_Util.insert();
    }

}
