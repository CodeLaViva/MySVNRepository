package com.lhz;

/**
 * 创建SearchEmp， 实现查找数据表tb_emp中销售部所有成员的功能
 */
public class Exercise1 {

    public static void main(String[] args) {
        Jdbc_Util.query("sales");
    }
}
