package com.lhz.example;

public class Example_02 {

    int i;
    public float f;
    protected boolean b;
    private String s;
}
