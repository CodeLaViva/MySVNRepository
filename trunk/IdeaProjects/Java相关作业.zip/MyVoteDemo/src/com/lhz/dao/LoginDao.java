package com.lhz.dao;

public interface LoginDao {
    boolean login(String vote_username, String vote_password);
}
