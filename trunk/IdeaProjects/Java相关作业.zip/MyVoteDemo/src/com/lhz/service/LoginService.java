package com.lhz.service;

public interface LoginService {
    boolean login(String vote_username, String vote_password);
}
